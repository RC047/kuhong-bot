let handler = m => m.reply('Yaa Aku Disini??\n\nIngin Memulai Bot? Ketik !help atau !menu yaa ;)')

handler.customPrefix = /Kuhong|kuhong|hong|Hong/i
handler.command = new RegExp

module.exports = handler